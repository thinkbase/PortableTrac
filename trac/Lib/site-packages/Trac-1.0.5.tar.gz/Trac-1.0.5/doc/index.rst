================================
Trac |version| API Documentation
================================

:Release: |release|
:Date: |today|

*This is work in progress. The API is not yet fully covered, but what
you'll find here should be accurate, otherwise it's a bug and you're
welcome to open a ticket for reporting the problem.*

Content
=======

.. toctree::
   :maxdepth: 1

   api/index
   dev/testing

.. toctree::
   :hidden:

   glossary

.. ifconfig:: devel

   .. toctree::
      :hidden:

      todo


Indices and tables
==================

* :ref:`General Index <genindex>`
* :ref:`modindex`
* :ref:`search`
* :doc:`glossary`

.. ifconfig:: devel

   * :doc:`todo`

